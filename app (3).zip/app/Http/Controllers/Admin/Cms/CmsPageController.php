<?php

namespace App\Http\Controllers\Admin\Cms;

use App\Http\Controllers\Controller;
use App\Models\CmsPage;
use App\Services\Cms\WebsitePageSectionsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Throwable;

class CmsPageController extends Controller
{
    /**
     * @return array<int, string>
     */
    private function allowed(): array
    {
        return app(WebsitePageSectionsService::class)->allowedSlugs();
    }

    public function index(): View
    {
        return view('admin.cms.pages.index', ['slugs' => $this->allowed()]);
    }

    public function editWhoWeAre(): View
    {
        return $this->editPublicPage('who-we-are');
    }

    public function updateWhoWeAre(Request $request): RedirectResponse
    {
        return $this->updatePublicPage($request, 'who-we-are');
    }

    public function edit(string $slug): View
    {
        return $this->editPublicPage($slug);
    }

    public function update(Request $request, string $slug): RedirectResponse
    {
        return $this->updatePublicPage($request, $slug);
    }

    public function editPublicPage(string $slug): View
    {
        abort_unless(in_array($slug, $this->allowed(), true), 404);

        /** @var array<string, mixed> $defaults */
        $defaults = config('website_page_sections.pages.'.$slug, []);
        if (! is_array($defaults)) {
            $defaults = [];
        }

        $page = CmsPage::query()->firstOrCreate(
            ['slug' => $slug],
            [
                'title' => (string) (($defaults['_meta']['default_title'] ?? '') ?: $slug),
                'body' => '',
                'meta_description' => ($defaults['_meta']['default_meta'] ?? null) ?: null,
                'sections' => null,
            ]
        );

        $sectionsPretty = '';
        if (is_array($page->sections) && $page->sections !== []) {
            $sectionsPretty = (string) json_encode($page->sections, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        }

        return view('admin.cms.pages.edit', [
            'slug' => $slug,
            'page' => $page,
            'sectionsPretty' => $sectionsPretty,
        ]);
    }

    public function updatePublicPage(Request $request, string $slug): RedirectResponse
    {
        abort_unless(in_array($slug, $this->allowed(), true), 404);

        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'meta_description' => ['nullable', 'string', 'max:500'],
            'sections_json' => ['nullable', 'string'],
        ]);

        $sections = [];
        if (! empty(trim((string) ($validated['sections_json'] ?? '')))) {
            try {
                $decoded = json_decode(trim((string) $validated['sections_json']), true, flags: JSON_THROW_ON_ERROR);
                $sections = is_array($decoded) ? $decoded : [];
            } catch (Throwable $e) {
                return redirect()
                    ->back()
                    ->withInput()
                    ->withErrors(['sections_json' => 'Sections must be valid JSON: '.$e->getMessage()]);
            }
        }

        CmsPage::query()->updateOrCreate(
            ['slug' => $slug],
            [
                'title' => $validated['title'],
                'body' => $validated['body'] ?? '',
                'meta_description' => $validated['meta_description'] ?? null,
                'sections' => $sections === [] ? null : $sections,
            ]
        );

        WebsitePageSectionsService::forgetCache($slug);

        return redirect()
            ->route('admin.cms.pages.edit', ['slug' => $slug])
            ->with('status', 'Website page sections saved.');
    }
}
