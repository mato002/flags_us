@extends('layouts.admin')

@section('title', 'Website Page CMS | Effective Media')

@section('header')
    Edit · {{ str_replace('-', ' ', $slug) }}
@endsection

@section('content')
    @include('admin.partials.page-header', [
        'title' => 'Structured sections · '.$slug,
        'description' => 'Titles + meta behave like legacy pages; JSON merges into config defaults shipped with the codebase.',
        'breadcrumb' => 'Website CMS · Pages · Edit',
    ])

    <form method="POST" action="{{ route('admin.cms.pages.update', ['slug' => $slug]) }}" class="space-y-5 rounded-lg border border-slate-200 bg-white p-6 text-sm dark:border-white/10 dark:bg-white/[0.04]">
        @csrf
        @method('PUT')

        <div>
            <label for="title" class="block text-xs font-semibold uppercase text-slate-500 dark:text-[#cbbfb6]">Browser title</label>
            <input id="title" name="title" value="{{ old('title', $page->title) }}" required class="mt-1 w-full rounded border border-slate-300 px-3 py-2 dark:border-white/20 dark:bg-transparent dark:text-white">
            @error('title')<p class="mt-1 text-xs text-rose-600">{{ $message }}</p>@enderror
        </div>

        <div>
            <label for="meta_description" class="block text-xs font-semibold uppercase text-slate-500 dark:text-[#cbbfb6]">Meta description</label>
            <input id="meta_description" name="meta_description" value="{{ old('meta_description', $page->meta_description) }}" maxlength="500" class="mt-1 w-full rounded border border-slate-300 px-3 py-2 dark:border-white/20 dark:bg-transparent dark:text-white">
            @error('meta_description')<p class="mt-1 text-xs text-rose-600">{{ $message }}</p>@enderror
        </div>

        <div>
            <label for="body" class="block text-xs font-semibold uppercase text-slate-500 dark:text-[#cbbfb6]">Legacy body (optional HTML)</label>
            <textarea id="body" name="body" rows="10" class="mt-1 w-full rounded border border-slate-300 px-3 py-2 font-mono text-xs dark:border-white/20 dark:bg-transparent dark:text-white">{{ old('body', $page->body) }}</textarea>
        </div>

        <div>
            <label for="sections_json" class="block text-xs font-semibold uppercase text-slate-500 dark:text-[#cbbfb6]">Section overrides JSON</label>
            <textarea id="sections_json" name="sections_json" rows="20" class="mt-1 w-full rounded border border-slate-300 px-3 py-2 font-mono text-xs dark:border-white/20 dark:bg-transparent dark:text-white">{{ old('sections_json', $sectionsPretty) }}</textarea>
            @error('sections_json')<p class="mt-1 text-xs text-rose-600">{{ $message }}</p>@enderror
            <p class="mt-2 text-xs text-slate-500 dark:text-[#a89f98]">Tip: cherry-pick keys from config/website_page_sections.php — only edited keys need appear here.</p>
        </div>

        <div class="flex flex-wrap gap-2">
            <button type="submit" class="rounded-md bg-[#8b1e1a] px-4 py-2 text-sm font-semibold text-white hover:bg-[#f04a2a]">Save merged content</button>
            <a href="{{ url('/'.$slug) }}" target="_blank" rel="noopener" class="rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold dark:border-white/20 dark:text-white">View live route</a>
            <a href="{{ route('admin.cms.pages.index') }}" class="rounded-md px-4 py-2 text-sm font-semibold text-slate-600 underline-offset-2 hover:underline dark:text-[#cbbfb6]">All pages</a>
        </div>
    </form>
@endsection
