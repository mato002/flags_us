@extends('layouts.admin')

@section('title', 'Website Pages | Effective Media')
@section('header', 'Website pages')

@section('content')
    @include('admin.partials.page-header', [
        'title' => 'Section-driven website pages',
        'description' => 'Each slug carries structured JSON merged with codebase defaults.',
        'breadcrumb' => 'Website CMS · Pages',
    ])

    <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        @foreach ($slugs as $slug)
            <a href="{{ route('admin.cms.pages.edit', ['slug' => $slug]) }}" class="rounded-xl border border-slate-200 bg-white p-4 text-sm shadow-sm transition hover:border-[#8b1e1a]/40 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-[#f04a2a]/40">
                <p class="text-xs font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-[#cbbfb6]">{{ str_replace('-', ' ', $slug) }}</p>
                <p class="mt-2 font-semibold text-slate-900 dark:text-white">Edit CMS sections</p>
                <p class="mt-1 text-xs text-slate-600 dark:text-[#bfb4ad]">{{ $slug }}</p>
            </a>
        @endforeach
    </div>
@endsection
